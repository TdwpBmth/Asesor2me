<?php
require_once "Genericas.php";
require_once "Bd.php";
require_once "Usuario.php";
require_once "Mensajes.php";
require_once "Preguntas.php";
require_once "Comentarios.php";

// Autoloader chafa